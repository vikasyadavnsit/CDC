package com.vikasyadavnsit.cdc.services;

import lombok.AllArgsConstructor;


@AllArgsConstructor
public class ScheduledWorker implements Runnable {

    @Override
    public void run() {

    }
}
