package com.vikasyadavnsit.cdc.enums;

import lombok.Getter;

@Getter
public enum AppStatus {
    OPEN,
    CLOSED_AFTER_OPENING;
}
